package knapsack 

/** This file describes the basic elements to build a problem instance and solution:
 *  An item, that can be put in the knapsack, and a Problem, that is a set of items
 *  A Solution is simply a sequence of boolean denoting whether each object is taken
 */

case class Item(value: Int) extends Ordered[Item]{
  require(value>=0, "Value "+value+" must be >= 0")
 
  override def compare(that: Item): Int = this.value.compareTo(that.value)
  override def toString() = ""+ value;
}

case class Problem(intItems: Seq[Int], capacity: Int) {
	require(intItems.nonEmpty, "There must be at least one item")
  require(capacity > 0, "Capacity "+capacity+" must be >= 0")

  val items = intItems.map( Item( _ ) )
  override def toString() = items.foldLeft("")((sofar,item) => sofar + " %2d".format(item.value))+" Searching for capacity:"+capacity
}
	
/** @brief Represents a partial solution
 *  The taken sequence may be shorter than the amount of objects if you did not consider all objects yet */
case class Solution(taken: Seq[Boolean], problem:Problem) {
  require(taken.length <= problem.items.length,"Your partial solution contains more objects than the problem instance")
  
  /* This is the sum of the values of all taken items */
  lazy val value = { (taken zip problem.items).foldLeft(0) ( { case (current, (taken,Item(value))) => if (taken) current+value else current })}
  
  /* Builds a new partial solution that takes the next possible object */
  def takeOne()  = Solution(taken ++ Seq(true),  problem) 
  /* Builds a new partial solution that leaves the next possible object */
  def leaveOne() = Solution(taken ++ Seq(false), problem)
  
  /* Returns whether the solution is a partial solution or not */
  lazy val isPartial = taken.length < problem.items.length
  
  /* The padding is useful to display partial solutions, such as "N N Y Y . . . ." in which 4 of 8 items were considered.
   * Of course, the objects that were not considered yet are not taken and are thus very similar to N, but representing 
   *   them differently greatly helps understanding the graphical outputs.
   */
  override def toString() = {
    val takenPart = taken.foldLeft("") ( (sofar,t) => if (t) sofar+ " Y " else sofar + " N ")
    val neededPadding = problem.items.length - taken.length /* Add spaces if not all objects are taken */ 
    var padding = ""
    for (i <- 1 to neededPadding) 
      padding += " .."
    takenPart + padding
  }
}
