package knapsack

/** This file simply contains some random instances to test your code. 
 *  
 *  If you have some nice instances (built on purpose to break code), please report them */

object TestInstances {
  val pb5  = new Problem(Seq(5, 4, 3, 2, 1), 10)
  val pb10 = new Problem(Seq(32, 37, 16, 78, 31, 66, 13, 18, 16, 9), 200)
  val pb20 = Problem(Seq(56, 33, 95, 62, 51, 97, 53, 22, 72, 81, 21, 32, 52, 86, 97, 12, 47, 79, 13, 28), 400)
  val pb25 = Problem(Seq(24, 99, 37, 43, 69, 86, 11, 23, 21, 36, 55, 59, 65, 61, 61, 58, 49, 41, 35, 25, 11, 88, 59, 33, 20), 500)
  val pb30 = Problem(Seq(16, 56, 16, 81, 86, 91, 22, 78, 79, 72, 98, 14, 92, 69, 29, 12, 56, 11, 77, 36, 97, 54, 11, 69, 33, 83, 42, 33, 25, 98), 600)
  val pb40 = Problem(Seq(12, 22, 38, 11, 21, 26, 34, 63, 22, 37, 69, 34, 59, 53, 81, 21, 31, 57, 11, 26, 21, 13, 16, 46, 86, 11, 31, 93, 81, 17, 81, 14, 32, 68, 19, 44, 75, 15, 18, 40), 800)
  val pb50 = Problem(Seq(53, 42, 62, 96, 89, 81, 83, 58, 18, 44, 64, 83, 13, 31, 36, 45, 44, 46, 55, 55, 59, 72, 63, 64, 52, 83, 66, 51, 28, 16, 16, 83, 14, 19, 66, 41, 26, 19, 95, 64, 31, 11, 62, 26, 86, 46, 17, 62, 24, 94), 1000)
}

