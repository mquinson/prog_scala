package knapsack

/** This file is the template for the exhaustive search. 
 *  - It generates all possible solutions, 
 *  - filters out the impossible solutions,
 *  - selects the maximal remaining solution.
 *  
 *  It is veeery inefficient for large instances
 */
object ExhaustiveSearch {
  	def apply(problem:Problem): Solution = {
  	  println("Exhaustive search")
  		println(problem)

  		def generateAll(depth: Int, current:Solution): List[Solution] = {
      /* Your code here */
  			  List(current)
  		}
  		val allSolutions: List[Solution] = generateAll(0, Solution(Nil, problem)) 
  		println("There is "+allSolutions.length+" solutions")
  		
     /* Find the best solution here */
  		
      allSolutions.head /* THIS IS WRONG, this returns any solution, not the best one, not even a valid one. But we want the code to compile */
  	}
}

object TestExhaustiveSearch extends App {
  val begin = System.currentTimeMillis()
  val sol = ExhaustiveSearch(TestInstances.pb20)
  val end = System.currentTimeMillis()

  println("Solution found in "+(end-begin)+"ms: "+sol.toString()+ ". Value: "+sol.value)
}