package knapsack

/** This file is the template for the selective search:
 *  - Each node initiate a recursion if maxdepth is not reached, and returns Some(the max of its possible child), or None if no possible child
 *  
 *  No variable and efficient, that's nice
 */
object SelectiveSearch {
  	def apply(problem:Problem): Solution = {
  	  println("Selective search")
  		println(problem)

  		def search(depth: Int, current:Solution): Option[Solution] = {
  	      /* Your code here */
  			Some(current)
  		}
  		search(0, Solution(Nil, problem)) match {
  		  case Some(v) => v
  		}
  	}
}

object TestSelectiveSearch extends App {
	val begin = System.currentTimeMillis()
  val sol = SelectiveSearch(TestInstances.pb25)
  val end = System.currentTimeMillis()

  println("Solution found in "+(end-begin)+"ms: "+sol.toString()+ ". Value: "+sol.value)
}