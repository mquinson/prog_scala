package knapsack;
/** This file is the template to the Branch&Bound solution:
 *  - It traverses the whole tree of possible solutions (branch) and stores the best found solution when hitting leafs
 *  - Impossible partial that already overruns the knapsack capacity are pruned (bound).
 *  
 *  This solution contains too much variables to fulfill the FP principles.
 *  It won't even be faster than the SelectiveSearch because it uses immutable data too.
 */
object BranchBoundSolver {
	type partialSolution = Seq[Boolean]

	def apply(problem:Problem): Solution = {
	  println("Branch and Bound")
	  println(problem.toString())
	  
	  var best:Solution = Solution(Nil, problem)
	  

	  search(0, best)
	  def search(depth: Int, current: Solution): Unit = {
	  /* Perform here your Branch & Bound search */
	  }
	  
	  best
	}
}

object TestBranchBoundSolver extends App {
  val begin = System.currentTimeMillis()
  val sol = BranchBoundSolver(TestInstances.pb25)
  val end = System.currentTimeMillis()
  println("Solution found in "+(end-begin)+"ms: "+sol.toString()+ ". Value: "+sol.value)
}