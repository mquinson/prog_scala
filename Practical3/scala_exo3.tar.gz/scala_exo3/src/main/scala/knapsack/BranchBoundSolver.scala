package knapsack;
/** This file is the template to the Branch&Bound solution:
 *  - It traverses the whole tree of possible solutions (branch) and stores the best found solution when hitting leafs
 *  - Impossible partial that already overruns the knapsack capacity are pruned (bound).
 *  
 *  This solution contains too much variables to fulfill the FP principles.
 *  It won't even be faster than the SelectiveSearch because it uses immutable data too.
 *  
 *  At the end of this file, you can see the outputOn the pb5 instance, my version program generates the following output:
 *   
 */
object BranchBoundSolver {
	type partialSolution = Seq[Boolean]

	def apply(problem:Problem): Solution = {
	  println("Branch and Bound")
	  println(problem.toString())
	  
	  var best:Solution = Solution(Nil, problem)
	  

	  /* Traverse all existing solutions, saving the best known on the way */
	  search(0, best)
	  def search(depth: Int, current: Solution): Unit = {
	    /* Perform here your Branch & Bound search */
	  }
	  
	  best
	}
}

object TestBranchBoundSolver extends App {
  val begin = System.currentTimeMillis()
  val sol = BranchBoundSolver(TestInstances.pb5)
  val end = System.currentTimeMillis()
  println("Solution found in "+(end-begin)+"ms: "+sol.toString()+ ". Value: "+sol.value)
}

/* Here is the output that my version generates for the pb5 instance:
 
Branch and Bound
  5  4  3  2  1 Searching for capacity:10
 .. .. .. .. ..
 Y  .. .. .. ..  New best solution (5)
 Y  Y  .. .. ..  New best solution (9)
 Y  Y  Y  .. .. *** Ooops, capacity exeeded (backtrack)
 Y  Y  N  .. ..
 Y  Y  N  Y  .. *** Ooops, capacity exeeded (backtrack)
 Y  Y  N  N  ..
 Y  Y  N  N  Y   New best solution (10)
 Y  Y  N  N  N 
 Y  N  .. .. ..
 Y  N  Y  .. ..
 Y  N  Y  Y  ..
 Y  N  Y  Y  Y  *** Ooops, capacity exeeded (backtrack)
 Y  N  Y  Y  N 
 Y  N  Y  N  ..
 Y  N  Y  N  Y 
 Y  N  Y  N  N 
 Y  N  N  .. ..
 Y  N  N  Y  ..
 Y  N  N  Y  Y 
 Y  N  N  Y  N 
 Y  N  N  N  ..
 Y  N  N  N  Y 
 Y  N  N  N  N 
 N  .. .. .. ..
 N  Y  .. .. ..
 N  Y  Y  .. ..
 N  Y  Y  Y  ..
 N  Y  Y  Y  Y 
 N  Y  Y  Y  N 
 N  Y  Y  N  ..
 N  Y  Y  N  Y 
 N  Y  Y  N  N 
 N  Y  N  .. ..
 N  Y  N  Y  ..
 N  Y  N  Y  Y 
 N  Y  N  Y  N 
 N  Y  N  N  ..
 N  Y  N  N  Y 
 N  Y  N  N  N 
 N  N  .. .. ..
 N  N  Y  .. ..
 N  N  Y  Y  ..
 N  N  Y  Y  Y 
 N  N  Y  Y  N 
 N  N  Y  N  ..
 N  N  Y  N  Y 
 N  N  Y  N  N 
 N  N  N  .. ..
 N  N  N  Y  ..
 N  N  N  Y  Y 
 N  N  N  Y  N 
 N  N  N  N  ..
 N  N  N  N  Y 
 N  N  N  N  N 
Solution found in 149ms:  Y  Y  N  N  Y . Value: 10
 * 
 */
