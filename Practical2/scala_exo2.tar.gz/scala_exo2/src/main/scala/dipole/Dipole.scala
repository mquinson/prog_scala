package dipole

trait Dipole {
    def impedance(omega: Double): Complex
}

