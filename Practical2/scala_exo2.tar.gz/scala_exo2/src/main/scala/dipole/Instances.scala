package dipole

object Instances {
	val dip1 = Resistor(1)
	
	val dip2 = Resistor(1)
}
